// Button Color Change
document.getElementById('colorButton').addEventListener('click', function() {
    this.style.backgroundColor = this.style.backgroundColor === 'blue' ? 'green' : 'blue';
});

// Greeting Alert
document.getElementById('greetingButton').addEventListener('click', function() {
    const hours = new Date().getHours();
    let greeting;

    if (hours < 12) {
        greeting = "Good morning!";
    } else if (hours < 18) {
        greeting = "Good afternoon!";
    } else {
        greeting = "Good evening!";
    }

    alert(greeting);
});

// Basic Calculator
document.getElementById('addButton').addEventListener('click', function() {
    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);
    const result = num1 + num2;

    document.getElementById('result').innerText = "Result: " + result;
});